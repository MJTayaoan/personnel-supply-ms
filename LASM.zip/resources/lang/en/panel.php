<?php

return [
    'site_title' => 'Personnel Supply Management System',
];
